import {FeatureFlag, FeatureFlagProvider} from "@/lib/feature-flags";
import {AppRouter} from "@/app-router.tsx";

const initialFlags: FeatureFlag[] = [
  {
    id: "advanced-analytics",
    name: "Advanced Analytics",
    description: "Enable advanced analytics visualizations",
    type: "feature",
    enabled: false,
  },
  {
    id: "component-data-grid",
    name: "Enhanced Data Grid",
    description: "Use the enhanced data grid component",
    type: "component",
    enabled: false,
  },
  {
    id: "premium-features",
    name: "Premium Features",
    description: "Enable premium features",
    type: "feature",
    category: "premium",
    enabled: false,
  },
  {
    id: "experimental-ui",
    name: "Experimental UI",
    description: "Enable experimental UI components",
    type: "feature",
    category: "experimental",
    enabled: false,
  },
  {
    id: "route-settings",
    name: "Settings Page",
    description: "Allow access to the settings page",
    type: "route",
    enabled: true,
  },
]

function App() {
  return (
      <FeatureFlagProvider initialFlags={initialFlags}>
        <AppRouter />
      </FeatureFlagProvider>
  )
}

export default App
