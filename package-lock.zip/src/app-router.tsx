import {BrowserRouter, Navigate, Route, Routes} from "react-router";
import FeatureFlagLayout from "@/feature-flags/layout/feature-flag-layout.tsx";

export const AppRouter = () => {
    return (
        <BrowserRouter>
            <Routes>
                <Route path='/feature-flags' element={<FeatureFlagLayout />}>
                    <Route path='login' element={<h1>Hello login</h1>} />
                    <Route path='register' element={<h1>Hello login</h1>} />
                </Route>


                <Route path="/" element={<Navigate to="/feature-flags" />} />
                <Route path="*" element={<Navigate to="/feature-flags" />} />
            </Routes>
        </BrowserRouter>
    )
}